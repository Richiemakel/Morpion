Voila un jeu Tictactoe crée avec react et et TyseScript:
Je vous invite pour lancer le projet à :
- Vous placer dans le terminal dans le dossier du projet 
- Composer la commande "npm i" afin de créer le dossier "nodes_modules"
- taper la commande "npm run dev" pour lancer le projet