/**
 * DO NOT UPDATE
 * This is the main entry point of the application.
 */

// import { BrowserRouter } from 'react-router-dom';
// import { AppRouter } from './chore/Router';
import Test from './components/Jeu/Jeu'
const App = () => {
  return (
    // <BrowserRouter>
      <Test/>
      //{/* <AppRouter /> */}
   // {/* </BrowserRouter> */}
  );
};

export default App;
